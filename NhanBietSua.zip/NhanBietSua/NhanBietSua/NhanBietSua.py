﻿
from flask import Flask, request, jsonify, send_file
import torch
from PIL import Image
import cv2
import numpy as np
import os

app = Flask(__name__)

# Load YOLOv5 model
try:
    model = torch.hub.load('ultralytics/yolov5', 'custom', path='D:\\c#\\NhanBietSua\\NhanBietSua\\best.pt', force_reload=True)
except Exception as e:
    print(f"Lỗi khi tải model: {e}")

# Đường dẫn lưu file
UPLOAD_FOLDER = 'D:\\c#\\NhanBietSua\\NhanBietSua\\uploads'
RESULT_FOLDER = 'D:\\c#\\NhanBietSua\\NhanBietSua\\results'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

# Cấp quyền ghi cho thư mục
os.chmod(UPLOAD_FOLDER, 0o777)
os.chmod(RESULT_FOLDER, 0o777)

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    
    file = request.files['file']
    if file:
        try:
            # Lưu file vào thư mục theo tên file
            input_path = os.path.join(UPLOAD_FOLDER, os.path.basename(file.filename))
            result_path = os.path.join(RESULT_FOLDER, os.path.basename(file.filename))
            file.save(input_path)

            # Đọc ảnh và nhận diện bằng YOLOv5
            img = Image.open(input_path).convert('RGB')
            results = model(img)

            #Vẽ bounding box lên ảnh
            boxes = results.xyxy[0].cpu().numpy()
            img_cv2 = cv2.imread(input_path)

            for box in boxes:
                x1, y1, x2, y2, conf, cls = box
                label = f'{results.names[int(cls)]} {conf:.2f}'
                cv2.rectangle(img_cv2, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
                cv2.putText(img_cv2, label, (int(x1), int(y1) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

            # Lưu ảnh kết quả
            cv2.imwrite(result_path, img_cv2)

            # Trả về ảnh đã nhận diện
            return send_file(result_path, mimetype='image/jpeg')

        except Exception as e:
            return jsonify({'error': f'Lỗi khi nhận diện: {e}'}), 500
    
    return jsonify({'result': "Không có file"}), 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
