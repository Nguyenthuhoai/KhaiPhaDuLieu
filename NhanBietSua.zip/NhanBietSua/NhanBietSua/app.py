﻿# Import các thư viện cần thiết
from flask import Flask, request, jsonify  # Flask dùng để tạo web server, request để lấy dữ liệu gửi lên, jsonify để trả kết quả dạng JSON
import torch  # Thư viện dùng để load và chạy mô hình YOLOv5
from PIL import Image  # Dùng để xử lý ảnh (mở ảnh, chuyển định dạng)
import pathlib  # Dùng để xử lý đường dẫn file

# Fix lỗi PosixPath khi chạy trên Windows
# YOLOv5 mặc định dùng PosixPath (dành cho Linux), sẽ lỗi nếu chạy trên Windows
temp = pathlib.PosixPath
pathlib.PosixPath = pathlib.WindowsPath

# Khởi tạo ứng dụng Flask
app = Flask(__name__)

# Load mô hình YOLOv5 đã được train (best.pt)
try:
    model = torch.hub.load('ultralytics/yolov5', 'custom', path='best.pt', force_reload=False)
except Exception as e:
    print(f"Lỗi khi tải model: {e}")

# Định nghĩa API endpoint /predict để nhận ảnh và trả kết quả nhận diện
@app.route('/predict', methods=['POST'])
def predict():
    # Kiểm tra xem có file trong request không
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400

    file = request.files['file']  # Lấy file từ request

    if file:
        try:
            # Mở ảnh và chuyển sang định dạng RGB
            img = Image.open(file).convert('RGB')

            # Dự đoán đối tượng trong ảnh bằng YOLOv5
            results = model(img)

            # Tạo danh sách kết quả nhận diện
            detections = []
            for *box, conf, cls in results.xyxy[0]:  # Lặp qua các kết quả (tọa độ bounding box, độ chính xác, lớp)
                detections.append({
                    'x_min': box[0].item(),  # Tọa độ góc trái trên
                    'y_min': box[1].item(),
                    'x_max': box[2].item(),  # Tọa độ góc phải dưới
                    'y_max': box[3].item(),
                    'confidence': conf.item(),  # Độ chính xác
                    'name': model.names[int(cls)]  # Tên lớp (ví dụ: milo, vinamilk, ...)
                })

            # Trả kết quả nhận diện dạng JSON
            if detections:
                return jsonify({'result': detections})
            else:
                return jsonify({'result': []})  # Không phát hiện đối tượng nào
        except Exception as e:
            return jsonify({'error': f'Lỗi khi nhận diện: {e}'})

    return jsonify({'result': []})  # Trường hợp không có file hợp lệ

# Chạy server Flask tại cổng 5000
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
