﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GiaoDien
{
    public partial class Form1 : Form
    {
        // Khởi tạo HttpClient dùng để gửi yêu cầu HTTP đến Flask server
        private static readonly HttpClient client = new HttpClient();

        public Form1()
        {
            InitializeComponent();
        }

        // Xử lý sự kiện khi nhấn nút "Upload"
        private async void btnUpload_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.jfif";  // Chỉ chọn file ảnh

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = openFileDialog.FileName;

                    try
                    {
                        // Giải phóng ảnh cũ nếu có
                        if (pictureBox.Image != null)
                        {
                            pictureBox.Image.Dispose();
                        }

                        // Hiển thị ảnh vừa chọn lên PictureBox
                        pictureBox.Image = Image.FromFile(filePath);

                        // Gửi ảnh đến Flask API để nhận diện
                        await SendImage(filePath);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Lỗi khi tải ảnh: {ex.Message}");
                    }
                }
            }
        }

        // Gửi ảnh tới Flask API và xử lý kết quả trả về
        private async Task SendImage(string filePath)
        {
            using (var content = new MultipartFormDataContent())
            {
                // Đọc file ảnh thành mảng byte
                var fileContent = new ByteArrayContent(File.ReadAllBytes(filePath));
                fileContent.Headers.ContentType = MediaTypeHeaderValue.Parse("multipart/form-data");

                // Gửi file với tên trường là 'file' như Flask yêu cầu
                content.Add(fileContent, "file", Path.GetFileName(filePath));

                try
                {
                    // Gửi yêu cầu POST đến Flask server
                    var response = await client.PostAsync("http://127.0.0.1:5000/predict", content);

                    if (response.IsSuccessStatusCode)
                    {
                        var json = await response.Content.ReadAsStringAsync();

                        // Phân tích JSON trả về từ Flask
                        using (JsonDocument document = JsonDocument.Parse(json))
                        {
                            JsonElement root = document.RootElement;

                            // Kiểm tra xem có kết quả trả về không
                            if (root.TryGetProperty("result", out JsonElement results) && results.GetArrayLength() > 0)
                            {
                                var boxes = new List<Dictionary<string, object>>();

                                foreach (var element in results.EnumerateArray())
                                {
                                    var box = new Dictionary<string, object>
                                    {
                                        { "x_min", element.GetProperty("x_min").GetSingle() },
                                        { "y_min", element.GetProperty("y_min").GetSingle() },
                                        { "x_max", element.GetProperty("x_max").GetSingle() },
                                        { "y_max", element.GetProperty("y_max").GetSingle() },
                                        { "confidence", element.GetProperty("confidence").GetSingle() },
                                        { "name", element.GetProperty("name").GetString() }
                                    };
                                    boxes.Add(box);
                                }

                                // Vẽ bounding boxes lên ảnh và hiển thị
                                DrawBoundingBoxes(boxes, filePath);
                            }
                            else
                            {
                                MessageBox.Show("Không nhận diện được đối tượng.");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Không nhận diện được đối tượng.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi khi gọi API: {ex.Message}");
                }
            }
        }

        // Vẽ bounding boxes và hiển thị thông tin dinh dưỡng
        private void DrawBoundingBoxes(List<Dictionary<string, object>> boxes, string filePath)
        {
            Image img = Image.FromFile(filePath);
            HashSet<string> detectedNamesSet = new HashSet<string>();  // Lưu tên các loại sữa duy nhất đã phát hiện

            // Dữ liệu dinh dưỡng tương ứng với từng loại sữa
            Dictionary<string, string> nutritionInfo = new Dictionary<string, string>
            {
                { "Dalatmilk", "Năng lượng 65kcal\nChất béo 3.8g\nChất đạm 3.2g\nHydrat cacbon 4.5g\nCanxi 103mg\nCác vitamin và khoáng chất có sẵn trong sữa tươi" },
                { "Fami", "Năng lượng 50,2kcal\nChất đạm 2.5g\nChất béo 1.4g\nCarbohydrate 6.9g\nNatri 25mg\nCanxi 80mg\nKẽm 380mcg\nMagiê 18mg\nVitamin A 160IU\nVitamin D3 48IU\nVitamin B6 160mcg\nVitamin B9 32mcg\nVitamin B12 0.23mcg\nCholesterol 0mg" },
                { "Milo", "Năng lượng 105kcal\nChất béo 3.8g\nChất đạm 2.4g\nCarbohydrate 15.4g\nCanxi 105mg\nPhốt-pho 92.0mg\nSắt 1.92mg\nVitamin B2 0.26mg\nVitamin B3 2.61mg\nVitamin B6 0.21mg\nVitamin D 34.3IU" },
                { "Vinamilkoccho", "Năng lượng 68.0kcal\nChất đạm 2.0g\nChất béo 3.6g\nHydrat cacbon 6.9g\nVitamin A 175IU\nVitamin D3 60IU\nVitamin E 1.0mg\nVitamin PP 1.0mg\nOmega-3 100mg" },
                { "Vinamilksuatuoi", "Năng lượng 75.1kcal\nChất béo 3.5g\nChất đạm 3.0g\nHydrat cacbon 7.9g\nVitamin A 250IU\nVitamin D3 165IU\nCanxi 110mg\nPhốt-pho 90mg\nSelen 7.6µg" }
            };

            using (Graphics g = Graphics.FromImage(img))
            {
                foreach (var box in boxes)
                {
                    // Lấy toạ độ và nhãn từ box
                    float x = Convert.ToSingle(box["x_min"]);
                    float y = Convert.ToSingle(box["y_min"]);
                    float width = Convert.ToSingle(box["x_max"]) - x;
                    float height = Convert.ToSingle(box["y_max"]) - y;
                    string name = box["name"].ToString();
                    string label = $"{name}: {Convert.ToSingle(box["confidence"]):P1}"; // Tỷ lệ phần trăm

                    // Vẽ khung chữ nhật quanh đối tượng
                    using (Pen pen = new Pen(Color.DarkBlue, 2))
                    {
                        g.DrawRectangle(pen, x, y, width, height);
                    }

                    // Vẽ nhãn tên + độ chính xác
                    float labelY = y - 40;
                    if (labelY < 0) labelY = y + height + 5;

                    using (SolidBrush brush = new SolidBrush(Color.DarkBlue))
                    using (Font font = new Font("Times New Roman", 30, FontStyle.Regular))
                    {
                        g.DrawString(label, font, brush, x, labelY);
                    }

                    // Thêm tên vào danh sách đã phát hiện nếu chưa có
                    if (!detectedNamesSet.Contains(name) && nutritionInfo.ContainsKey(name))
                    {
                        detectedNamesSet.Add(name);
                    }
                }
            }

            // Hiển thị ảnh đã có bounding box
            pictureBox.Image = img;

            // Cập nhật tbInfo với thông tin dinh dưỡng
            if (detectedNamesSet.Count > 0)
            {
                List<string> detectedList = new List<string>(detectedNamesSet);
                tbInfo.Text = string.Join("\n\n", detectedList.ConvertAll(name => $"{name}:\n{nutritionInfo[name]}"));
            }
            else
            {
                tbInfo.Text = "Không có thông tin dinh dưỡng phù hợp";
            }
        }
    }
}
